# topsis102217164Ayush

This is a basic implementation of the TOPSIS method for decision analysis, written in Python. The package provides a simple way to calculate the TOPSIS score and rank alternatives based on their performance with respect to multiple criteria.

## Installation

You can install the package using pip:

```bash
pip install topsis102217164Ayush
